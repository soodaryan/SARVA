// src/components/Dashboard.js
import React from 'react';
import './Dashboard.css'; 
const Dashboard = () => {
  return (
    <div className='heading'> SARVA </div>
  );
};

export default Dashboard;
